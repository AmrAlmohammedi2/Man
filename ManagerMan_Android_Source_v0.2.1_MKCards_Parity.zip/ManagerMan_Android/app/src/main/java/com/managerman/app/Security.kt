package com.managerman.app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Device-bound AES/GCM encryption for router credentials at rest. */
object DeviceCrypto {
    private const val ALIAS = "ManagerMan.RouterCredentials.v1"

    private fun getKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun encrypt(plain: String): String {
        if (plain.isEmpty()) return ""
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getKey())
        val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        return "K1:" + Base64.encodeToString(packed, Base64.NO_WRAP)
    }

    fun decrypt(value: String): String {
        if (value.isEmpty()) return ""
        if (!value.startsWith("K1:")) return value // migrate legacy plaintext preference values
        val packed = Base64.decode(value.removePrefix("K1:"), Base64.NO_WRAP)
        require(packed.size > 12) { "بيانات كلمة المرور المخزنة غير صالحة" }
        val iv = packed.copyOfRange(0, 12)
        val data = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(data), Charsets.UTF_8)
    }
}

/** Password-based encryption for portable backup files (independent of the source phone). */
object BackupCrypto {
    private const val MAGIC = "MGM-BACKUP-1\n"
    private const val ITERATIONS = 210_000
    private const val KEY_BITS = 256

    private fun derive(passphrase: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(passphrase, salt, ITERATIONS, KEY_BITS)
        return try {
            val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            SecretKeySpec(raw, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    fun encrypt(plain: ByteArray, passphrase: String): ByteArray {
        require(passphrase.length >= 8) { "اجعل كلمة مرور النسخة الاحتياطية 8 أحرف على الأقل" }
        val salt = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
        val key = derive(passphrase.toCharArray(), salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val encrypted = cipher.doFinal(plain)
        return (MAGIC.toByteArray(Charsets.UTF_8) + salt + cipher.iv + encrypted)
    }

    fun decrypt(blob: ByteArray, passphrase: String): ByteArray {
        val magic = MAGIC.toByteArray(Charsets.UTF_8)
        require(blob.size > magic.size + 28 && blob.copyOfRange(0, magic.size).contentEquals(magic)) {
            "هذا الملف ليس نسخة احتياطية صالحة لمديرمان"
        }
        var offset = magic.size
        val salt = blob.copyOfRange(offset, offset + 16); offset += 16
        val iv = blob.copyOfRange(offset, offset + 12); offset += 12
        val cipherText = blob.copyOfRange(offset, blob.size)
        val key = derive(passphrase.toCharArray(), salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(cipherText)
    }
}
