package com.managerman.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.security.SecureRandom
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF10243A)
private val Teal = Color(0xFF00A896)
private val Canvas = Color(0xFFF3F6F9)
private val Ink = Color(0xFF182B3A)
private val Muted = Color(0xFF718096)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ManagerManApp(this) }
    }
}

private data class RouterSnapshot(
    val info: RouterInfo,
    val hotspotUsers: List<HotspotUser>,
    val hotspotProfiles: List<PackageProfile>,
    val activeSessions: List<NetworkSession>,
    val umUsers: List<UmUser>,
    val umProfiles: List<PackageProfile>,
    val umSessions: List<NetworkSession>,
    val umPayments: List<UmPayment>,
    val umError: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagerManApp(context: Context) {
    val store = remember { LocalStore(context) }
    val scope = rememberCoroutineScope()

    var tab by remember { mutableIntStateOf(0) }
    var morePage by remember { mutableStateOf("menu") }
    var routers by remember { mutableStateOf(store.routers()) }
    var selectedRouter by remember { mutableStateOf(routers.firstOrNull()) }
    var hotspotUsers by remember { mutableStateOf(emptyList<HotspotUser>()) }
    var hotspotProfiles by remember { mutableStateOf(emptyList<PackageProfile>()) }
    var activeSessions by remember { mutableStateOf(emptyList<NetworkSession>()) }
    var umUsers by remember { mutableStateOf(emptyList<UmUser>()) }
    var umProfiles by remember { mutableStateOf(emptyList<PackageProfile>()) }
    var umSessions by remember { mutableStateOf(emptyList<NetworkSession>()) }
    var umPayments by remember { mutableStateOf(emptyList<UmPayment>()) }
    var routerInfo by remember { mutableStateOf(RouterInfo()) }
    var umError by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("محلي • لم يتم تحديث البيانات بعد") }
    var busy by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var cards by remember { mutableStateOf(store.cards()) }
    var sales by remember { mutableStateOf(store.sales()) }
    var design by remember { mutableStateOf(store.design()) }

    var showRouterDialog by remember { mutableStateOf(false) }
    var showHotspotUserDialog by remember { mutableStateOf(false) }
    var showUmUserDialog by remember { mutableStateOf(false) }
    var showHotspotProfileDialog by remember { mutableStateOf(false) }
    var showUmProfileDialog by remember { mutableStateOf(false) }
    var showGeneratorDialog by remember { mutableStateOf(false) }
    var showDesignDialog by remember { mutableStateOf(false) }
    var showSaleDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }

    var routerName by remember { mutableStateOf("") }
    var routerHost by remember { mutableStateOf("") }
    var routerPort by remember { mutableStateOf("8728") }
    var routerUser by remember { mutableStateOf("admin") }
    var routerPassword by remember { mutableStateOf("") }

    var newUsername by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var newProfile by remember { mutableStateOf("default") }
    var newComment by remember { mutableStateOf("") }
    var sharedUsers by remember { mutableStateOf("1") }

    var profileName by remember { mutableStateOf("") }
    var profileRate by remember { mutableStateOf("") }
    var profileValidity by remember { mutableStateOf("1d") }
    var profilePrice by remember { mutableStateOf("0") }
    var profileShared by remember { mutableStateOf("1") }

    var generatorTarget by remember { mutableStateOf("Hotspot") }
    var generatorCount by remember { mutableStateOf("20") }
    var generatorUserLength by remember { mutableStateOf("6") }
    var generatorPasswordLength by remember { mutableStateOf("6") }
    var generatorPrefix by remember { mutableStateOf("") }
    var generatorProfile by remember { mutableStateOf("default") }
    var generatorPrice by remember { mutableStateOf("0") }
    var generatorBusy by remember { mutableStateOf(false) }

    var designNetworkName by remember { mutableStateOf(design.networkName) }
    var designTitle by remember { mutableStateOf(design.title) }
    var designFooter by remember { mutableStateOf(design.footer) }
    var designTemplate by remember { mutableStateOf(design.template) }
    var designShowPassword by remember { mutableStateOf(design.showPassword) }
    var designShowPrice by remember { mutableStateOf(design.showPrice) }

    var saleUsername by remember { mutableStateOf("") }
    var saleProfile by remember { mutableStateOf("") }
    var saleAmount by remember { mutableStateOf("") }
    var saleCustomer by remember { mutableStateOf("") }
    var saleNote by remember { mutableStateOf("") }
    var backupPassword by remember { mutableStateOf("") }
    var backupBusy by remember { mutableStateOf(false) }

    fun reloadRouterList() {
        routers = store.routers()
        if (selectedRouter == null) selectedRouter = routers.firstOrNull()
    }

    fun refreshData() {
        val router = selectedRouter
        if (router == null) {
            status = "أضف راوتراً أولاً"
            return
        }
        busy = true
        status = "جارٍ قراءة بيانات الراوتر…"
        scope.launch {
            try {
                val snapshot = withContext(Dispatchers.IO) {
                    val api = RouterOsApi(router)
                    val info = api.routerInfo()
                    val hsUsers = api.hotspotUsers()
                    val hsProfiles = api.hotspotProfiles()
                    val sessions = api.activeHotspotSessions()
                    var users = emptyList<UmUser>()
                    var profiles = emptyList<PackageProfile>()
                    var umHistory = emptyList<NetworkSession>()
                    var payments = emptyList<UmPayment>()
                    var error: String? = null
                    try {
                        users = api.userManagerUsers()
                        profiles = api.userManagerProfiles()
                        umHistory = api.userManagerSessions()
                        payments = api.userManagerPayments()
                    } catch (e: Exception) {
                        error = e.message ?: "User Manager غير متاح أو لا توجد صلاحية للوصول إليه"
                    }
                    RouterSnapshot(info, hsUsers, hsProfiles, sessions, users, profiles, umHistory, payments, error)
                }
                routerInfo = snapshot.info
                hotspotUsers = snapshot.hotspotUsers
                hotspotProfiles = snapshot.hotspotProfiles
                activeSessions = snapshot.activeSessions
                umUsers = snapshot.umUsers
                umProfiles = snapshot.umProfiles
                umSessions = snapshot.umSessions
                umPayments = snapshot.umPayments
                umError = snapshot.umError
                status = "متصل • ${snapshot.info.version.ifBlank { "RouterOS" }} • تم تحديث البيانات"
                generatorProfile = if (generatorTarget == "Hotspot") hotspotProfiles.firstOrNull()?.name ?: "default"
                    else umProfiles.firstOrNull()?.name ?: ""
            } catch (e: Exception) {
                status = "فشل التحديث: ${e.message ?: "تعذر الاتصال"}"
            } finally {
                busy = false
            }
        }
    }

    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) { CardPdf.write(context, uri, cards, design) }
                    status = "تم تصدير ${cards.size} بطاقة إلى PDF"
                } catch (e: Exception) { status = "تعذر إنشاء PDF: ${e.message}" }
            }
        }
    }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                backupBusy = true
                try {
                    val encrypted = withContext(Dispatchers.IO) {
                        BackupCrypto.encrypt(store.backupJson().toByteArray(Charsets.UTF_8), backupPassword)
                    }
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(encrypted) }
                            ?: error("تعذر فتح ملف النسخة الاحتياطية")
                    }
                    status = "تم إنشاء نسخة احتياطية مشفرة"
                    showBackupDialog = false
                    backupPassword = ""
                } catch (e: Exception) { status = "فشل النسخ الاحتياطي: ${e.message}" }
                finally { backupBusy = false }
            }
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                backupBusy = true
                try {
                    val clear = withContext(Dispatchers.IO) {
                        val blob = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: error("تعذر قراءة ملف النسخة الاحتياطية")
                        BackupCrypto.decrypt(blob, backupPassword)
                    }
                    store.restoreJson(String(clear, Charsets.UTF_8))
                    reloadRouterList()
                    cards = store.cards()
                    sales = store.sales()
                    design = store.design()
                    status = "تمت استعادة النسخة الاحتياطية بنجاح"
                    showBackupDialog = false
                    backupPassword = ""
                } catch (e: Exception) { status = "فشلت الاستعادة: ${e.message ?: "كلمة المرور غير صحيحة"}" }
                finally { backupBusy = false }
            }
        }
    }

    LaunchedEffect(selectedRouter?.host) {
        if (selectedRouter != null) refreshData()
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Navy, background = Canvas, surface = Color.White)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("مديرمان", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                            Text("MANAGERMAN  •  MIKROTIK", color = Color(0xFFB9D5D7), fontSize = 10.sp, letterSpacing = 1.3.sp)
                        }
                    },
                    actions = {
                        if (routers.isNotEmpty()) {
                            IconButton(onClick = { refreshData() }, enabled = !busy) {
                                if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                else Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = Color.White)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val nav = listOf(
                        Triple("الرئيسية", Icons.Default.Dashboard, 0),
                        Triple("Hotspot", Icons.Default.Wifi, 1),
                        Triple("User Manager", Icons.Default.People, 2),
                        Triple("الكروت", Icons.Default.CreditCard, 3),
                        Triple("المزيد", Icons.Default.MoreHoriz, 4)
                    )
                    nav.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item.third,
                            onClick = { tab = item.third; if (item.third == 4) morePage = "menu" },
                            icon = { Icon(item.second, contentDescription = item.first) },
                            label = { Text(item.first, fontSize = 10.sp, maxLines = 1) }
                        )
                    }
                }
            },
            floatingActionButton = {
                when (tab) {
                    1 -> FloatingActionButton(onClick = { newUsername = ""; newPassword = ""; newProfile = hotspotProfiles.firstOrNull()?.name ?: "default"; showHotspotUserDialog = true }, containerColor = Teal) { Icon(Icons.Default.Add, null, tint = Color.White) }
                    2 -> FloatingActionButton(onClick = { newUsername = ""; newPassword = ""; newProfile = umProfiles.firstOrNull()?.name.orEmpty(); showUmUserDialog = true }, containerColor = Teal) { Icon(Icons.Default.Add, null, tint = Color.White) }
                    3 -> FloatingActionButton(onClick = { showGeneratorDialog = true }, containerColor = Teal) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White) }
                    4 -> if (morePage == "sales") FloatingActionButton(onClick = { saleUsername = ""; saleProfile = ""; saleAmount = ""; saleCustomer = ""; saleNote = ""; showSaleDialog = true }, containerColor = Teal) { Icon(Icons.Default.Add, null, tint = Color.White) }
                }
            },
            containerColor = Canvas
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 15.dp)) {
                Spacer(Modifier.height(10.dp))
                when (tab) {
                    0 -> DashboardScreen(
                        status, selectedRouter, routerInfo, hotspotUsers.size, umUsers.size, activeSessions.size,
                        cards.size, sales.sumOf { it.amount }, busy,
                        onConnect = { refreshData() }, onChooseRouter = { tab = 4; morePage = "routers" },
                        onCards = { tab = 3; showGeneratorDialog = true }, onSessions = { tab = 4; morePage = "sessions" },
                        onHotspot = { tab = 1 }, onUserManager = { tab = 2 },
                        onProfiles = { tab = 4; morePage = "profiles" }, onSales = { tab = 4; morePage = "sales" },
                        onReports = { tab = 4; morePage = "reports" },
                        onBackup = { backupPassword = ""; showBackupDialog = true }
                    )
                    1 -> HotspotScreen(hotspotUsers, hotspotProfiles, search, { search = it }, onDelete = { user ->
                        val r = selectedRouter
                        if (r != null) scope.launch {
                            try {
                                withContext(Dispatchers.IO) { RouterOsApi(r).removeHotspotUser(user.id) }
                                hotspotUsers = hotspotUsers.filterNot { it.id == user.id }
                                status = "تم حذف المستخدم ${user.name}"
                            } catch (e: Exception) { status = "تعذر الحذف: ${e.message}" }
                        }
                    }, onToggle = { user ->
                        val r = selectedRouter
                        if (r != null) scope.launch {
                            try {
                                withContext(Dispatchers.IO) { RouterOsApi(r).setHotspotUserDisabled(user.id, !user.disabled) }
                                hotspotUsers = hotspotUsers.map { if (it.id == user.id) it.copy(disabled = !user.disabled) else it }
                            } catch (e: Exception) { status = "تعذر تعديل المستخدم: ${e.message}" }
                        }
                    }, onProfiles = { tab = 4; morePage = "profiles-hotspot" })
                    2 -> UserManagerScreen(umUsers, umProfiles, search, { search = it }, umError,
                        onDelete = { user ->
                            val r = selectedRouter
                            if (r != null) scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { RouterOsApi(r).removeUserManagerUser(user.id) }
                                    umUsers = umUsers.filterNot { it.id == user.id }
                                    status = "تم حذف مستخدم User Manager"
                                } catch (e: Exception) { status = "تعذر الحذف: ${e.message}" }
                            }
                        }, onToggle = { user ->
                            val r = selectedRouter
                            if (r != null) scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { RouterOsApi(r).setUserManagerUserDisabled(user.id, !user.disabled) }
                                    umUsers = umUsers.map { if (it.id == user.id) it.copy(disabled = !user.disabled) else it }
                                } catch (e: Exception) { status = "تعذر تعديل مستخدم User Manager: ${e.message}" }
                            }
                        }, onProfiles = { tab = 4; morePage = "profiles-um" })
                    3 -> CardsScreen(cards, design, onDesign = {
                        designNetworkName = design.networkName; designTitle = design.title; designFooter = design.footer
                        designTemplate = design.template; designShowPassword = design.showPassword; designShowPrice = design.showPrice
                        showDesignDialog = true
                    }, onExport = { if (cards.isNotEmpty()) pdfLauncher.launch("ManagerMan-Cards.pdf") else status = "لا توجد كروت لتصديرها" },
                        onGenerator = { showGeneratorDialog = true }, onSell = { c ->
                            saleUsername = c.username; saleProfile = c.profile; saleAmount = c.price.toString()
                            saleCustomer = ""; saleNote = "بيع بطاقة"; showSaleDialog = true
                        })
                    4 -> MoreScreen(
                        page = morePage,
                        routers = routers,
                        selected = selectedRouter,
                        sessions = activeSessions,
                        umSessions = umSessions,
                        umPayments = umPayments,
                        umProfiles = umProfiles,
                        hotspotProfiles = hotspotProfiles,
                        sales = sales,
                        status = status,
                        onPage = { morePage = it },
                        onAddRouter = { routerName = ""; routerHost = ""; routerPort = "8728"; routerUser = "admin"; routerPassword = ""; showRouterDialog = true },
                        onSelectRouter = { selectedRouter = it; status = "تم اختيار ${it.name}" },
                        onDeleteRouter = { r -> store.removeRouter(r.host); reloadRouterList(); status = "تم حذف إعداد الراوتر من الهاتف" },
                        onDisconnect = { session ->
                            val r = selectedRouter
                            if (r != null) scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { RouterOsApi(r).disconnectHotspotSession(session.id) }
                                    activeSessions = activeSessions.filterNot { it.id == session.id }
                                    status = "تم فصل جلسة ${session.username}"
                                } catch (e: Exception) { status = "تعذر فصل الجلسة: ${e.message}" }
                            }
                        },
                        onAddHotspotProfile = { profileName = ""; profileRate = ""; profileShared = "1"; showHotspotProfileDialog = true },
                        onAddUmProfile = { profileName = ""; profileValidity = "1d"; profilePrice = "0"; showUmProfileDialog = true },
                        onDeleteHotspotProfile = { profile ->
                            val r = selectedRouter
                            if (r != null) scope.launch {
                                try { withContext(Dispatchers.IO) { RouterOsApi(r).removeHotspotProfile(profile.name) }; refreshData(); status = "تم حذف باقة Hotspot" }
                                catch (e: Exception) { status = "تعذر حذف الباقة: ${e.message}" }
                            }
                        },
                        onDeleteUmProfile = { profile ->
                            val r = selectedRouter
                            if (r != null) scope.launch {
                                try { withContext(Dispatchers.IO) { RouterOsApi(r).removeUserManagerProfile(profile.name) }; refreshData(); status = "تم حذف باقة User Manager" }
                                catch (e: Exception) { status = "تعذر حذف الباقة: ${e.message}" }
                            }
                        },
                        onBackup = { backupPassword = ""; showBackupDialog = true },
                        onRefresh = { refreshData() }
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // Router configuration dialog
        if (showRouterDialog) AlertDialog(
            onDismissRequest = { showRouterDialog = false },
            title = { Text("إضافة راوتر MikroTik") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(routerName, { routerName = it }, label = { Text("اسم الراوتر") }, singleLine = true)
                OutlinedTextField(routerHost, { routerHost = it }, label = { Text("IP أو DNS") }, singleLine = true)
                OutlinedTextField(routerPort, { routerPort = it }, label = { Text("منفذ API (8728)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(routerUser, { routerUser = it }, label = { Text("اسم مستخدم API") }, singleLine = true)
                OutlinedTextField(routerPassword, { routerPassword = it }, label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                Text("تُحفظ كلمة المرور مشفرة على الهاتف. لا تفتح منفذ API على الإنترنت العام.", fontSize = 11.sp, color = Muted)
            } },
            confirmButton = { TextButton(onClick = {
                val r = RouterProfile(routerName.ifBlank { "MikroTik" }, routerHost.trim(), routerPort.toIntOrNull() ?: 8728, routerUser, routerPassword)
                if (r.host.isBlank()) status = "أدخل عنوان الراوتر" else {
                    store.saveRouter(r); reloadRouterList(); selectedRouter = r; showRouterDialog = false
                    status = "تم حفظ إعدادات الراوتر بشكل مشفر"
                }
            }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { showRouterDialog = false }) { Text("إلغاء") } }
        )

        if (showHotspotUserDialog) AlertDialog(
            onDismissRequest = { showHotspotUserDialog = false }, title = { Text("إضافة مستخدم Hotspot") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(newUsername, { newUsername = it }, label = { Text("اسم المستخدم") }, singleLine = true)
                OutlinedTextField(newPassword, { newPassword = it }, label = { Text("كلمة المرور") }, singleLine = true)
                OutlinedTextField(newProfile, { newProfile = it }, label = { Text("الباقة / Profile") }, singleLine = true)
                OutlinedTextField(newComment, { newComment = it }, label = { Text("ملاحظة (اختياري)") }, singleLine = true)
            } },
            confirmButton = { TextButton(onClick = {
                val r = selectedRouter
                if (r == null || newUsername.isBlank()) status = "اختر راوتراً وأدخل اسم المستخدم" else scope.launch {
                    try {
                        withContext(Dispatchers.IO) { RouterOsApi(r).addHotspotUser(newUsername, newPassword, newProfile.ifBlank { "default" }, newComment) }
                        status = "تم إنشاء مستخدم Hotspot"; refreshData()
                    } catch (e: Exception) { status = "فشل إنشاء المستخدم: ${e.message}" }
                }
                showHotspotUserDialog = false
            }) { Text("إنشاء") } },
            dismissButton = { TextButton(onClick = { showHotspotUserDialog = false }) { Text("إلغاء") } }
        )

        if (showUmUserDialog) AlertDialog(
            onDismissRequest = { showUmUserDialog = false }, title = { Text("إضافة مستخدم User Manager") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(newUsername, { newUsername = it }, label = { Text("اسم المستخدم") }, singleLine = true)
                OutlinedTextField(newPassword, { newPassword = it }, label = { Text("كلمة المرور") }, singleLine = true)
                OutlinedTextField(newProfile, { newProfile = it }, label = { Text("اسم الباقة / Profile") }, singleLine = true)
                OutlinedTextField(sharedUsers, { sharedUsers = it }, label = { Text("عدد الجلسات المتزامنة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                if (routerInfo.version.startsWith("6.")) Text("RouterOS 6: سيتم استخدام مسار User Manager القديم مع customer=admin.", fontSize = 11.sp, color = Muted)
            } },
            confirmButton = { TextButton(onClick = {
                val r = selectedRouter
                if (r == null || newUsername.isBlank()) status = "اختر راوتراً وأدخل اسم المستخدم" else scope.launch {
                    try {
                        withContext(Dispatchers.IO) { RouterOsApi(r).addUserManagerUser(newUsername, newPassword, newProfile, sharedUsers.toIntOrNull() ?: 1) }
                        status = "تم إنشاء مستخدم User Manager"; refreshData()
                    } catch (e: Exception) { status = "فشل إنشاء المستخدم: ${e.message}" }
                }
                showUmUserDialog = false
            }) { Text("إنشاء") } },
            dismissButton = { TextButton(onClick = { showUmUserDialog = false }) { Text("إلغاء") } }
        )

        if (showHotspotProfileDialog) AlertDialog(
            onDismissRequest = { showHotspotProfileDialog = false }, title = { Text("إنشاء باقة Hotspot") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(profileName, { profileName = it }, label = { Text("اسم الباقة") }, singleLine = true)
                OutlinedTextField(profileRate, { profileRate = it }, label = { Text("Rate Limit مثال 2M/2M") }, singleLine = true)
                OutlinedTextField(profileShared, { profileShared = it }, label = { Text("Shared Users") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            } },
            confirmButton = { TextButton(onClick = {
                val r = selectedRouter
                if (r != null && profileName.isNotBlank()) scope.launch {
                    try {
                        withContext(Dispatchers.IO) { RouterOsApi(r).addHotspotProfile(PackageProfile(profileName, profileRate, profileShared)) }
                        status = "تم إنشاء باقة Hotspot"; refreshData()
                    } catch (e: Exception) { status = "فشل إنشاء الباقة: ${e.message}" }
                }
                showHotspotProfileDialog = false
            }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { showHotspotProfileDialog = false }) { Text("إلغاء") } }
        )

        if (showUmProfileDialog) AlertDialog(
            onDismissRequest = { showUmProfileDialog = false }, title = { Text("إنشاء باقة User Manager") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(profileName, { profileName = it }, label = { Text("اسم الباقة") }, singleLine = true)
                OutlinedTextField(profileValidity, { profileValidity = it }, label = { Text("الصلاحية مثال 1d أو 12h") }, singleLine = true)
                OutlinedTextField(profilePrice, { profilePrice = it }, label = { Text("السعر") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                if (routerInfo.version.startsWith("6.")) Text("سيتم إنشاء الباقة ضمن User Manager القديم في RouterOS 6.", fontSize = 11.sp, color = Muted)
            } },
            confirmButton = { TextButton(onClick = {
                val r = selectedRouter
                if (r != null && profileName.isNotBlank()) scope.launch {
                    try {
                        withContext(Dispatchers.IO) { RouterOsApi(r).addUserManagerProfile(PackageProfile(profileName, validity = profileValidity, price = profilePrice)) }
                        status = "تم إنشاء باقة User Manager"; refreshData()
                    } catch (e: Exception) { status = "فشل إنشاء الباقة: ${e.message}" }
                }
                showUmProfileDialog = false
            }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { showUmProfileDialog = false }) { Text("إلغاء") } }
        )

        if (showGeneratorDialog) AlertDialog(
            onDismissRequest = { if (!generatorBusy) showGeneratorDialog = false },
            title = { Text("إنشاء كروت الإنترنت") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = generatorTarget == "Hotspot", onClick = { generatorTarget = "Hotspot"; generatorProfile = hotspotProfiles.firstOrNull()?.name ?: "default" }, label = { Text("Hotspot") })
                    FilterChip(selected = generatorTarget == "User Manager", onClick = { generatorTarget = "User Manager"; generatorProfile = umProfiles.firstOrNull()?.name.orEmpty() }, label = { Text("User Manager") })
                }
                OutlinedTextField(generatorProfile, { generatorProfile = it }, label = { Text("الباقة كما تظهر في الراوتر") }, singleLine = true)
                OutlinedTextField(generatorCount, { generatorCount = it }, label = { Text("العدد (1 – 500)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(generatorUserLength, { generatorUserLength = it }, label = { Text("طول اسم المستخدم") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(generatorPasswordLength, { generatorPasswordLength = it }, label = { Text("طول كلمة المرور") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(generatorPrefix, { generatorPrefix = it }, label = { Text("بادئة اسم المستخدم (اختياري)") }, singleLine = true)
                OutlinedTextField(generatorPrice, { generatorPrice = it }, label = { Text("سعر البطاقة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                if (generatorBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("سيتم إنشاء الحسابات مباشرة على الراوتر ثم حفظ بيانات الكروت محلياً.", fontSize = 11.sp, color = Muted)
            } },
            confirmButton = { TextButton(enabled = !generatorBusy, onClick = {
                val r = selectedRouter
                val count = generatorCount.toIntOrNull() ?: 0
                val userLen = generatorUserLength.toIntOrNull() ?: 6
                val passLen = generatorPasswordLength.toIntOrNull() ?: 6
                if (r == null) { status = "اختر راوتراً أولاً"; return@TextButton }
                if (count !in 1..500 || userLen !in 4..16 || passLen !in 4..24 || generatorProfile.isBlank()) {
                    status = "تحقق من العدد والأطوال واسم الباقة"; return@TextButton
                }
                generatorBusy = true
                scope.launch {
                    try {
                        val generated = makeCards(count, userLen, passLen, generatorPrefix, generatorProfile,
                            generatorTarget, generatorPrice.toDoubleOrNull() ?: 0.0)
                        val triples = generated.map { Triple(it.username, it.password, it.profile) }
                        val result = withContext(Dispatchers.IO) {
                            val api = RouterOsApi(r)
                            if (generatorTarget == "Hotspot") api.addHotspotUsersBulk(triples) else api.addUserManagerUsersBulk(triples)
                        }
                        val created = generated.take(result.createdCount)
                        cards = (created + cards).take(5000)
                        store.saveCards(cards)
                        if (result.error == null) status = "تم إنشاء ${result.createdCount} بطاقة وإضافتها إلى الراوتر"
                        else status = "تم إنشاء ${result.createdCount} من ${generated.size} بطاقة. الخطأ: ${result.error}"
                        refreshData()
                        showGeneratorDialog = false
                    } catch (e: Exception) { status = "فشل إنشاء الكروت: ${e.message}" }
                    finally { generatorBusy = false }
                }
            }) { Text("إنشاء على الراوتر") } },
            dismissButton = { TextButton(enabled = !generatorBusy, onClick = { showGeneratorDialog = false }) { Text("إلغاء") } }
        )

        if (showDesignDialog) AlertDialog(
            onDismissRequest = { showDesignDialog = false }, title = { Text("مصمم الكروت") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(designNetworkName, { designNetworkName = it }, label = { Text("اسم الشبكة") }, singleLine = true)
                OutlinedTextField(designTitle, { designTitle = it }, label = { Text("عنوان البطاقة") }, singleLine = true)
                OutlinedTextField(designFooter, { designFooter = it }, label = { Text("النص السفلي") }, singleLine = true)
                Text("القالب", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("أزرق", "أخضر", "داكن", "بنفسجي").forEach { v -> FilterChip(selected = designTemplate == v, onClick = { designTemplate = v }, label = { Text(v) }) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(designShowPassword, { designShowPassword = it }); Text("طباعة كلمة المرور")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(designShowPrice, { designShowPrice = it }); Text("طباعة السعر")
                }
            } },
            confirmButton = { TextButton(onClick = {
                design = CardDesign(designNetworkName, designTitle, designFooter, designTemplate, designShowPassword, designShowPrice)
                store.saveDesign(design); showDesignDialog = false; status = "تم حفظ تصميم الكروت"
            }) { Text("حفظ التصميم") } },
            dismissButton = { TextButton(onClick = { showDesignDialog = false }) { Text("إلغاء") } }
        )

        if (showSaleDialog) AlertDialog(
            onDismissRequest = { showSaleDialog = false }, title = { Text("تسجيل عملية بيع / دفع") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(saleUsername, { saleUsername = it }, label = { Text("اسم المستخدم أو رقم البطاقة") }, singleLine = true)
                OutlinedTextField(saleProfile, { saleProfile = it }, label = { Text("الباقة") }, singleLine = true)
                OutlinedTextField(saleAmount, { saleAmount = it }, label = { Text("المبلغ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(saleCustomer, { saleCustomer = it }, label = { Text("اسم العميل (اختياري)") }, singleLine = true)
                OutlinedTextField(saleNote, { saleNote = it }, label = { Text("ملاحظة") }, singleLine = true)
                Text("هذا سجل محاسبي محلي للعملية، وليس بوابة دفع إلكترونية.", fontSize = 11.sp, color = Muted)
            } },
            confirmButton = { TextButton(onClick = {
                val amount = saleAmount.toDoubleOrNull()
                if (saleUsername.isBlank() || amount == null || amount < 0) status = "أدخل اسم البطاقة ومبلغاً صحيحاً" else {
                    val entry = SaleRecord(LocalStore.newId(), saleUsername, saleProfile, amount, saleCustomer, saleNote, System.currentTimeMillis())
                    sales = listOf(entry) + sales; store.saveSales(sales); status = "تم تسجيل عملية البيع بقيمة $amount"; showSaleDialog = false
                }
            }) { Text("تسجيل") } },
            dismissButton = { TextButton(onClick = { showSaleDialog = false }) { Text("إلغاء") } }
        )

        if (showBackupDialog) AlertDialog(
            onDismissRequest = { if (!backupBusy) showBackupDialog = false }, title = { Text("نسخ احتياطي مشفر") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(backupPassword, { backupPassword = it }, label = { Text("كلمة مرور النسخة (8 أحرف على الأقل)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                Text("يتضمن الراوترات وبيانات الاتصال والكروت والتصميم وسجل المبيعات. احتفظ بكلمة المرور؛ لا يمكن استعادة الملف بدونها.", fontSize = 11.sp, color = Muted)
                if (backupBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
            } },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(enabled = !backupBusy && backupPassword.length >= 8, onClick = { restoreLauncher.launch(arrayOf("application/octet-stream", "*/*")) }) { Text("استعادة") }
                    TextButton(enabled = !backupBusy && backupPassword.length >= 8, onClick = { backupLauncher.launch("ManagerMan-Backup.mgmbackup") }) { Text("تصدير نسخة") }
                }
            },
            dismissButton = { TextButton(enabled = !backupBusy, onClick = { showBackupDialog = false }) { Text("إلغاء") } },
            icon = { Icon(Icons.Default.Lock, null, tint = Teal) }
        )
    }
}

@Composable
private fun DashboardScreen(
    status: String, router: RouterProfile?, info: RouterInfo, hotspotCount: Int, umCount: Int,
    activeCount: Int, cardCount: Int, salesTotal: Double, busy: Boolean,
    onConnect: () -> Unit, onChooseRouter: () -> Unit, onCards: () -> Unit, onSessions: () -> Unit,
    onHotspot: () -> Unit, onUserManager: () -> Unit, onProfiles: () -> Unit,
    onSales: () -> Unit, onReports: () -> Unit, onBackup: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("لوحة التحكم", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text(status, fontSize = 11.sp, color = Muted)
                }
                if (busy) CircularProgressIndicator(Modifier.size(25.dp), strokeWidth = 2.dp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                StatCard("Hotspot", hotspotCount.toString(), Icons.Default.Wifi, Modifier.weight(1f))
                StatCard("User Manager", umCount.toString(), Icons.Default.People, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                StatCard("الجلسات النشطة", activeCount.toString(), Icons.Default.WifiTethering, Modifier.weight(1f))
                StatCard("الكروت المحفوظة", cardCount.toString(), Icons.Default.CreditCard, Modifier.weight(1f))
            }
        }
        item {
            Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(17.dp)) {
                    Text("الراوتر الحالي", color = Color(0xFFB9D5D7), fontSize = 12.sp)
                    Text(router?.name ?: "لم تتم إضافة راوتر", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(router?.host ?: "أضف عنوان الراوتر للبدء", color = Color.LightGray, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onConnect, colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                            Icon(Icons.Default.Sync, null); Spacer(Modifier.width(6.dp)); Text("تحديث الآن")
                        }
                        OutlinedButton(onClick = onChooseRouter, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("إدارة الراوترات") }
                    }
                }
            }
        }
        item {
            Text("معلومات الجهاز", fontWeight = FontWeight.Bold, color = Ink)
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    InfoLine("إصدار RouterOS", info.version.ifBlank { "—" })
                    InfoLine("اللوحة", info.board.ifBlank { "—" })
                    InfoLine("مدة التشغيل", info.uptime.ifBlank { "—" })
                    InfoLine("استخدام CPU", if (info.cpuLoad.isBlank()) "—" else "${info.cpuLoad}%")
                    InfoLine("الذاكرة الحرة", readableBytes(info.freeMemory))
                    InfoLine("إجمالي الذاكرة", readableBytes(info.totalMemory))
                }
            }
        }
        item {
            Text("الخدمات الرئيسية", fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                QuickAction("Hotspot", Icons.Default.Wifi, Modifier.weight(1f), onHotspot)
                QuickAction("User Manager", Icons.Default.People, Modifier.weight(1f), onUserManager)
                QuickAction("الجلسات", Icons.Default.WifiTethering, Modifier.weight(1f), onSessions)
            }
            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                QuickAction("إنشاء كروت", Icons.Default.AutoAwesome, Modifier.weight(1f), onCards)
                QuickAction("الباقات", Icons.Default.Inventory2, Modifier.weight(1f), onProfiles)
                QuickAction("المبيعات", Icons.Default.Payments, Modifier.weight(1f), onSales)
            }
            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                QuickAction("تقارير UM", Icons.Default.Assessment, Modifier.weight(1f), onReports)
                QuickAction("النسخ الاحتياطي", Icons.Default.Backup, Modifier.weight(1f), onBackup)
                QuickAction("إعداد الراوتر", Icons.Default.Router, Modifier.weight(1f), onChooseRouter)
            }
        }
        item { StatCard("إجمالي المبيعات المسجلة", String.format(Locale.US, "%.2f", salesTotal), Icons.Default.Payments, Modifier.fillMaxWidth()) }
    }
}

@Composable
private fun HotspotScreen(
    users: List<HotspotUser>, profiles: List<PackageProfile>, search: String, onSearch: (String) -> Unit,
    onDelete: (HotspotUser) -> Unit, onToggle: (HotspotUser) -> Unit, onProfiles: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("مستخدمو Hotspot", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink); Text("${users.size} مستخدم • ${profiles.size} باقة", fontSize = 11.sp, color = Muted) }
            TextButton(onClick = onProfiles) { Text("الباقات") }
        }
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth(), placeholder = { Text("بحث باسم المستخدم أو الباقة") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(7.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(users.filter { it.name.contains(search, true) || it.profile.contains(search, true) }, key = { it.id }) { user ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(13.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).background(Color(0xFFE3F5F2), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Teal) }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(user.name, color = Ink, fontWeight = FontWeight.SemiBold)
                            Text("${user.profile}${if (user.disabled) " • معطل" else " • فعال"}", color = Muted, fontSize = 11.sp)
                        }
                        IconButton(onClick = { onToggle(user) }) { Icon(if (user.disabled) Icons.Default.PlayArrow else Icons.Default.Pause, null, tint = Teal) }
                        IconButton(onClick = { onDelete(user) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFD45B5B)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun UserManagerScreen(
    users: List<UmUser>, profiles: List<PackageProfile>, search: String, onSearch: (String) -> Unit,
    error: String?, onDelete: (UmUser) -> Unit, onToggle: (UmUser) -> Unit, onProfiles: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("User Manager", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink); Text("${users.size} مستخدم • ${profiles.size} باقة", fontSize = 11.sp, color = Muted) }
            TextButton(onClick = onProfiles) { Text("الباقات") }
        }
        if (error != null) Text("ملاحظة: $error", color = Color(0xFF9C6500), fontSize = 11.sp)
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth(), placeholder = { Text("بحث في مستخدمي User Manager") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(7.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(users.filter { it.name.contains(search, true) || it.profile.contains(search, true) }, key = { it.id }) { user ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(13.dp)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).background(Color(0xFFE7EFF9), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AccountCircle, null, tint = Navy) }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(user.name, color = Ink, fontWeight = FontWeight.SemiBold)
                            Text("${user.profile.ifBlank { "بدون باقة ظاهرة" }}${if (user.disabled) " • معطل" else ""}", color = Muted, fontSize = 11.sp)
                        }
                        IconButton(onClick = { onToggle(user) }) { Icon(if (user.disabled) Icons.Default.PlayArrow else Icons.Default.Pause, null, tint = Teal) }
                        IconButton(onClick = { onDelete(user) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFD45B5B)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun CardsScreen(
    cards: List<CredentialCard>, design: CardDesign, onDesign: () -> Unit, onExport: () -> Unit,
    onGenerator: () -> Unit, onSell: (CredentialCard) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Text("الكروت والتصميم", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("${cards.size} بطاقة محفوظة محلياً • القالب: ${design.template}", fontSize = 11.sp, color = Muted)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Button(onClick = onGenerator, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(5.dp)); Text("توليد الكروت") }
            OutlinedButton(onClick = onDesign, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Palette, null); Spacer(Modifier.width(5.dp)); Text("تصميم الكرت") }
        }
        OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(7.dp)); Text("تصدير جميع الكروت PDF") }
        Spacer(Modifier.height(7.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(cards.take(500), key = { it.id }) { card ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(13.dp)) {
                    Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).background(Color(0xFFE7EFF9), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.CreditCard, null, tint = Navy) }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(card.username, color = Ink, fontWeight = FontWeight.Bold)
                            Text("${card.target} • ${card.profile} • ${card.password}", color = Muted, fontSize = 11.sp)
                        }
                        TextButton(onClick = { onSell(card) }) { Text("بيع") }
                    }
                }
            }
            if (cards.size > 500) item { Text("يعرض التطبيق أول 500 بطاقة في هذه القائمة؛ تصدير PDF يشمل جميع البطاقات.", color = Muted, fontSize = 11.sp) }
        }
    }
}

@Composable
private fun MoreScreen(
    page: String, routers: List<RouterProfile>, selected: RouterProfile?, sessions: List<NetworkSession>,
    umSessions: List<NetworkSession>, umPayments: List<UmPayment>, umProfiles: List<PackageProfile>, hotspotProfiles: List<PackageProfile>,
    sales: List<SaleRecord>, status: String, onPage: (String) -> Unit,
    onAddRouter: () -> Unit, onSelectRouter: (RouterProfile) -> Unit, onDeleteRouter: (RouterProfile) -> Unit,
    onDisconnect: (NetworkSession) -> Unit, onAddHotspotProfile: () -> Unit, onAddUmProfile: () -> Unit,
    onDeleteHotspotProfile: (PackageProfile) -> Unit, onDeleteUmProfile: (PackageProfile) -> Unit,
    onBackup: () -> Unit, onRefresh: () -> Unit
) {
    when (page) {
        "menu" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            item { Text("الأدوات والإدارة", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink) }
            item { MenuTile("إدارة الراوترات", "إضافة راوترات والتبديل بينها", Icons.Default.Router) { onPage("routers") } }
            item { MenuTile("الجلسات النشطة", "عرض الأجهزة المتصلة وفصل الجلسات", Icons.Default.WifiTethering) { onPage("sessions") } }
            item { MenuTile("الباقات والبروفايلات", "إدارة باقات Hotspot وUser Manager", Icons.Default.Inventory2) { onPage("profiles") } }
            item { MenuTile("تقارير User Manager", "جلسات الاستخدام وحركة البيانات", Icons.Default.Assessment) { onPage("reports") } }
            item { MenuTile("المبيعات والمدفوعات", "سجل البيع والإيرادات المحلية", Icons.Default.Payments) { onPage("sales") } }
            item { MenuTile("نسخ احتياطي واستعادة", "ملف مشفر قابل للنقل بين الهواتف", Icons.Default.Backup) { onBackup() } }
            item { MenuTile("تحديث بيانات الراوتر", status, Icons.Default.Sync) { onRefresh() } }
        }
        "routers" -> Column(Modifier.fillMaxSize()) {
            SubPageHeader("أجهزة MikroTik", onBack = { onPage("menu") }, action = "إضافة", onAction = onAddRouter)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(routers, key = { it.host }) { router ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(13.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable { onSelectRouter(router) }) {
                                Text(router.name, fontWeight = FontWeight.Bold, color = Ink)
                                Text("${router.host}:${router.port}", color = Muted, fontSize = 11.sp)
                                Text(if (selected?.host == router.host) "الراوتر المحدد" else "اضغط للتحديد", color = if (selected?.host == router.host) Teal else Muted, fontSize = 10.sp)
                            }
                            IconButton(onClick = { onDeleteRouter(router) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFD45B5B)) }
                        }
                    }
                }
                if (routers.isEmpty()) item { EmptyHint("لا توجد راوترات محفوظة") }
            }
        }
        "sessions" -> Column(Modifier.fillMaxSize()) {
            SubPageHeader("الجلسات النشطة", onBack = { onPage("menu") }, action = "تحديث", onAction = onRefresh)
            Text("${sessions.size} جلسة Hotspot نشطة", color = Muted, fontSize = 11.sp)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(sessions, key = { it.id }) { s ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.username, fontWeight = FontWeight.Bold, color = Ink)
                                Text("${s.address} • ${s.mac}", color = Muted, fontSize = 10.sp)
                                Text("المدة ${s.uptime} • تنزيل ${readableBytes(s.download)} • رفع ${readableBytes(s.upload)}", color = Muted, fontSize = 10.sp)
                            }
                            IconButton(onClick = { onDisconnect(s) }) { Icon(Icons.Default.LinkOff, null, tint = Color(0xFFD45B5B)) }
                        }
                    }
                }
            }
        }
        "profiles", "profiles-hotspot", "profiles-um" -> {
            val showHotspot = page != "profiles-um"
            val profiles = if (showHotspot) hotspotProfiles else umProfiles
            Column(Modifier.fillMaxSize()) {
                SubPageHeader("الباقات والبروفايلات", onBack = { onPage("menu") }, action = "إضافة", onAction = { if (showHotspot) onAddHotspotProfile() else onAddUmProfile() })
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    FilterChip(selected = showHotspot, onClick = { onPage("profiles-hotspot") }, label = { Text("Hotspot") })
                    FilterChip(selected = !showHotspot, onClick = { onPage("profiles-um") }, label = { Text("User Manager") })
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(profiles, key = { it.name }) { p ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.Bold, color = Ink)
                                    val detail = if (showHotspot) "Rate: ${p.rateLimit.ifBlank { "غير محدد" }} • Shared: ${p.sharedUsers}" else "الصلاحية: ${p.validity.ifBlank { "غير محددة" }} • السعر: ${p.price}"
                                    Text(detail, fontSize = 11.sp, color = Muted)
                                }
                                IconButton(onClick = { if (showHotspot) onDeleteHotspotProfile(p) else onDeleteUmProfile(p) }) {
                                    Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFD45B5B))
                                }
                            }
                        }
                    }
                    if (profiles.isEmpty()) item { EmptyHint("لم يتم العثور على باقات لهذا القسم") }
                }
            }
        }
        "reports" -> Column(Modifier.fillMaxSize()) {
            SubPageHeader("تقارير User Manager", onBack = { onPage("menu") }, action = "تحديث", onAction = onRefresh)
            val totalDown = umSessions.sumOf { it.download.toLongOrNull() ?: 0L }
            val totalUp = umSessions.sumOf { it.upload.toLongOrNull() ?: 0L }
            val approvedPayments = umPayments.filter { it.status.equals("approved", ignoreCase = true) }
            val paidTotal = approvedPayments.sumOf { it.price.toDoubleOrNull() ?: 0.0 }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                StatCard("سجلات الجلسات", umSessions.size.toString(), Icons.Default.ReceiptLong, Modifier.weight(1f))
                StatCard("التنزيل", readableBytes(totalDown.toString()), Icons.Default.Download, Modifier.weight(1f))
                StatCard("الرفع", readableBytes(totalUp.toString()), Icons.Default.Upload, Modifier.weight(1f))
            }
            Spacer(Modifier.height(7.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                StatCard("دفعات ناجحة", approvedPayments.size.toString(), Icons.Default.CheckCircle, Modifier.weight(1f))
                StatCard("إجمالي الدفعات", String.format(Locale.US, "%.2f", paidTotal), Icons.Default.Payments, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                item { Text("دفعات User Manager من الراوتر", fontWeight = FontWeight.Bold, color = Ink) }
                items(umPayments, key = { it.id }) { payment ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(11.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(payment.user.ifBlank { "مستخدم غير معروف" }, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                                Text("${payment.price} ${payment.currency}", color = Teal, fontWeight = FontWeight.Bold)
                            }
                            Text("${payment.profile} • ${payment.method.ifBlank { "طريقة غير محددة" }} • ${payment.status.ifBlank { "حالة غير معروفة" }}", color = Muted, fontSize = 10.sp)
                            Text("${payment.transStart.ifBlank { "بلا تاريخ" }}${if (payment.transEnd.isNotBlank()) " → ${payment.transEnd}" else ""}", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                if (umPayments.isEmpty()) item { Text("لا توجد دفعات User Manager مسجلة أو أن إصدار User Manager لا يعرضها عبر API.", color = Muted, fontSize = 11.sp) }
                item { Spacer(Modifier.height(4.dp)); Text("سجلات جلسات User Manager", fontWeight = FontWeight.Bold, color = Ink) }
                items(umSessions, key = { "session-${it.id}" }) { session ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(11.dp)) {
                            Text(session.username, fontWeight = FontWeight.Bold, color = Ink)
                            Text("${session.address} • مدة ${session.uptime}", color = Muted, fontSize = 11.sp)
                            Text("تنزيل ${readableBytes(session.download)} • رفع ${readableBytes(session.upload)}", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                if (umSessions.isEmpty()) item { EmptyHint("لا توجد سجلات جلسات متاحة. تأكد من تفعيل المحاسبة في RADIUS.") }
            }
        }
        "sales" -> Column(Modifier.fillMaxSize()) {
            SubPageHeader("المبيعات والمدفوعات", onBack = { onPage("menu") }, action = "تحديث", onAction = onRefresh)
            val total = sales.sumOf { it.amount }
            val today = sales.filter { sameDay(it.createdAt, System.currentTimeMillis()) }.sumOf { it.amount }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("إجمالي المبيعات", String.format(Locale.US, "%.2f", total), Icons.Default.Payments, Modifier.weight(1f))
                StatCard("مبيعات اليوم", String.format(Locale.US, "%.2f", today), Icons.Default.Today, Modifier.weight(1f))
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(sales, key = { it.id }) { sale ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(11.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(sale.username, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                                Text(String.format(Locale.US, "%.2f", sale.amount), color = Teal, fontWeight = FontWeight.Bold)
                            }
                            Text("${sale.profile} • ${sale.customer.ifBlank { "عميل غير محدد" }}", color = Muted, fontSize = 11.sp)
                            Text("${formatDate(sale.createdAt)}${if (sale.note.isNotBlank()) " • ${sale.note}" else ""}", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                if (sales.isEmpty()) item { EmptyHint("لا توجد عمليات بيع مسجلة بعد") }
            }
        }
        else -> EmptyHint("القسم غير متاح")
    }
}

@Composable
private fun SubPageHeader(title: String, onBack: () -> Unit, action: String, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Navy) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
        TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun MenuTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(13.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(43.dp).background(Color(0xFFE5F5F2), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Teal) }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold, color = Ink); Text(subtitle, fontSize = 11.sp, color = Muted) }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(13.dp)) {
            Icon(icon, null, tint = Teal, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(6.dp))
            Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink, maxLines = 1)
            Text(title, fontSize = 10.sp, color = Muted)
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), shape = RoundedCornerShape(13.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Teal); Spacer(Modifier.height(5.dp)); Text(label, fontSize = 11.sp, color = Ink)
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(value, color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun EmptyHint(text: String) {
    Box(Modifier.fillMaxWidth().padding(25.dp), contentAlignment = Alignment.Center) { Text(text, color = Muted, fontSize = 12.sp) }
}

private fun makeCards(count: Int, usernameLength: Int, passwordLength: Int, prefix: String,
                      profile: String, target: String, price: Double): List<CredentialCard> {
    val random = SecureRandom()
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    val reserved = mutableSetOf<String>()
    fun randomCode(length: Int): String = buildString { repeat(length) { append(chars[random.nextInt(chars.length)]) } }
    return (1..count).map {
        var username: String
        do { username = prefix + randomCode((usernameLength - prefix.length).coerceAtLeast(1)) } while (!reserved.add(username))
        CredentialCard(LocalStore.newId(), username, randomCode(passwordLength), profile, target, price, System.currentTimeMillis())
    }
}

private fun readableBytes(raw: String): String {
    val bytes = raw.toDoubleOrNull() ?: return if (raw.isBlank()) "—" else raw
    if (bytes < 1024) return "${bytes.toLong()} B"
    val units = listOf("KB", "MB", "GB", "TB")
    var value = bytes / 1024.0
    var index = 0
    while (value >= 1024 && index < units.lastIndex) { value /= 1024.0; index++ }
    return String.format(Locale.US, "%.1f %s", value, units[index])
}

private fun formatDate(timestamp: Long): String = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT, Locale.getDefault()).format(Date(timestamp))
private fun sameDay(a: Long, b: Long): Boolean {
    val ca = java.util.Calendar.getInstance().apply { timeInMillis = a }
    val cb = java.util.Calendar.getInstance().apply { timeInMillis = b }
    return ca.get(java.util.Calendar.YEAR) == cb.get(java.util.Calendar.YEAR) && ca.get(java.util.Calendar.DAY_OF_YEAR) == cb.get(java.util.Calendar.DAY_OF_YEAR)
}
