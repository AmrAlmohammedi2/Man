package com.managerman.app

import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest

/** RouterOS binary API client. Commands are sent one sentence per request.
 * Supports plain login (RouterOS >= 6.43 and current ROS) and legacy challenge response.
 */
class RouterOsApi(private val router: RouterProfile) {
    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var rosMajor: Int? = null
    private var umBase: String? = null

    private fun writeLength(out: OutputStream, length: Int) {
        when {
            length < 0x80 -> out.write(length)
            length < 0x4000 -> { out.write((length shr 8) or 0x80); out.write(length and 0xff) }
            length < 0x200000 -> {
                out.write((length shr 16) or 0xC0); out.write((length shr 8) and 0xff); out.write(length and 0xff)
            }
            length < 0x10000000 -> {
                out.write((length shr 24) or 0xE0); out.write((length shr 16) and 0xff)
                out.write((length shr 8) and 0xff); out.write(length and 0xff)
            }
            else -> {
                out.write(0xF0); out.write((length shr 24) and 0xff); out.write((length shr 16) and 0xff)
                out.write((length shr 8) and 0xff); out.write(length and 0xff)
            }
        }
    }

    private fun readByte(stream: InputStream): Int {
        val value = stream.read()
        if (value < 0) throw IllegalStateException("انقطع الاتصال بالراوتر")
        return value
    }

    private fun readLength(stream: InputStream): Int {
        val first = readByte(stream)
        return when {
            first and 0x80 == 0 -> first
            first and 0xC0 == 0x80 -> ((first and 0x3f) shl 8) or readByte(stream)
            first and 0xE0 == 0xC0 -> ((first and 0x1f) shl 16) or (readByte(stream) shl 8) or readByte(stream)
            first and 0xF0 == 0xE0 -> ((first and 0x0f) shl 24) or (readByte(stream) shl 16) or
                (readByte(stream) shl 8) or readByte(stream)
            else -> (readByte(stream) shl 24) or (readByte(stream) shl 16) or (readByte(stream) shl 8) or readByte(stream)
        }
    }

    private fun sendSentence(vararg words: String) {
        val out = output ?: error("الاتصال غير مفتوح")
        words.forEach { word ->
            val bytes = word.toByteArray(Charsets.UTF_8)
            writeLength(out, bytes.size)
            out.write(bytes)
        }
        out.write(0)
        out.flush()
    }

    private fun readSentence(): List<String> {
        val stream = input ?: error("الاتصال غير مفتوح")
        val result = mutableListOf<String>()
        while (true) {
            val length = readLength(stream)
            if (length == 0) return result
            require(length in 1..(4 * 1024 * 1024)) { "حجم رد غير متوقع من الراوتر" }
            val bytes = ByteArray(length)
            var offset = 0
            while (offset < length) {
                val count = stream.read(bytes, offset, length - offset)
                if (count < 0) throw IllegalStateException("انقطع الاتصال أثناء استقبال البيانات")
                offset += count
            }
            result += String(bytes, Charsets.UTF_8)
        }
    }

    private fun connect() {
        close()
        socket = Socket().apply {
            tcpNoDelay = true
            connect(InetSocketAddress(router.host, router.port), 8000)
            soTimeout = 12000
        }
        input = socket!!.getInputStream()
        output = socket!!.getOutputStream()

        // Modern login is preferred. Older RouterOS releases may answer with a challenge.
        sendSentence("/login", "=name=${router.user}", "=password=${router.pass}")
        var reply = readUntilDone()
        var challenge = reply.sentences.flatten().firstOrNull { it.startsWith("=ret=") }?.substringAfter("=ret=")
        if (reply.done && challenge.isNullOrBlank()) return

        if (challenge.isNullOrBlank()) {
            val message = reply.error ?: reply.sentences.flatten().joinToString(" ")
            if (message.contains("invalid user", true) || message.contains("password", true)) {
                throw IllegalStateException(message.ifBlank { "اسم المستخدم أو كلمة المرور غير صحيحة" })
            }
            // Retry with the legacy two-step login handshake on a clean socket.
            close()
            socket = Socket().apply {
                tcpNoDelay = true
                connect(InetSocketAddress(router.host, router.port), 8000)
                soTimeout = 12000
            }
            input = socket!!.getInputStream(); output = socket!!.getOutputStream()
            sendSentence("/login")
            reply = readUntilDone()
            challenge = reply.sentences.flatten().firstOrNull { it.startsWith("=ret=") }?.substringAfter("=ret=")
        }
        if (!reply.done || challenge.isNullOrBlank()) {
            throw IllegalStateException(reply.error ?: "تعذر تسجيل الدخول إلى الراوتر")
        }
        val challengeBytes = challenge.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        val md5 = MessageDigest.getInstance("MD5")
        md5.update(0.toByte())
        md5.update(router.pass.toByteArray(Charsets.UTF_8))
        val digest = md5.digest(challengeBytes).joinToString("") { "%02x".format(it) }
        sendSentence("/login", "=name=${router.user}", "=response=00$digest")
        val final = readUntilDone()
        if (!final.done) throw IllegalStateException(final.error ?: "فشل تسجيل الدخول")
    }

    private data class Reply(val sentences: List<List<String>>, val done: Boolean, val error: String? = null)

    private fun readUntilDone(): Reply {
        val sentences = mutableListOf<List<String>>()
        while (true) {
            val sentence = readSentence()
            if (sentence.isEmpty()) continue
            sentences += sentence
            when (sentence.firstOrNull()) {
                "!done" -> return Reply(sentences, true)
                "!trap", "!fatal" -> {
                    val message = sentence.firstOrNull { it.startsWith("=message=") }?.substringAfter("=message=")
                        ?: sentence.joinToString(" ")
                    return Reply(sentences, false, message)
                }
            }
        }
    }

    private fun decodeRow(sentence: List<String>): Map<String, String> {
        val row = linkedMapOf<String, String>()
        sentence.drop(1).forEach { word ->
            if (word.startsWith("=")) {
                val separator = word.indexOf('=', 1)
                if (separator > 0) row[word.substring(1, separator)] = word.substring(separator + 1)
            }
        }
        return row
    }

    private fun command(path: String, vararg arguments: String): List<Map<String, String>> {
        sendSentence(path, *arguments)
        val rows = mutableListOf<Map<String, String>>()
        while (true) {
            val sentence = readSentence()
            if (sentence.isEmpty()) continue
            when (sentence.first()) {
                "!re" -> rows += decodeRow(sentence)
                "!empty" -> Unit // ROS 7.18+ may send !empty before the terminal !done.
                "!done" -> return rows
                "!trap", "!fatal" -> {
                    val message = sentence.firstOrNull { it.startsWith("=message=") }?.substringAfter("=message=")
                        ?: sentence.joinToString(" ")
                    throw IllegalStateException(message)
                }
            }
        }
    }

    fun <T> withConnection(block: RouterOsApi.() -> T): T {
        connect()
        return try { block() } finally { close() }
    }

    private fun rows(path: String, vararg args: String): List<Map<String, String>> = command(path, *args)
    private fun add(path: String, vararg args: String) { command(path, *args) }
    private fun remove(path: String, id: String) { command(path, "=.id=$id") }

    fun routerInfo(): RouterInfo = withConnection {
        val row = rows("/system/resource/print").firstOrNull() ?: emptyMap()
        val version = row["version"].orEmpty()
        rosMajor = version.substringBefore('.').toIntOrNull()
        RouterInfo(
            version = version,
            board = row["board-name"] ?: row["platform"].orEmpty(),
            uptime = row["uptime"].orEmpty(),
            cpuLoad = row["cpu-load"].orEmpty(),
            freeMemory = row["free-memory"].orEmpty(),
            totalMemory = row["total-memory"].orEmpty()
        )
    }

    fun hotspotUsers(): List<HotspotUser> = withConnection {
        rows("/ip/hotspot/user/print").map {
            HotspotUser(it[".id"].orEmpty(), it["name"].orEmpty(), it["profile"] ?: "default",
                it["comment"].orEmpty(), it["disabled"] == "true" || it["disabled"] == "yes", it["limit-uptime"].orEmpty(),
                it["limit-bytes-total"].orEmpty())
        }
    }

    fun hotspotProfiles(): List<PackageProfile> = withConnection {
        rows("/ip/hotspot/user/profile/print").map {
            PackageProfile(it["name"].orEmpty(), it["rate-limit"].orEmpty(), it["shared-users"] ?: "1")
        }
    }

    fun activeHotspotSessions(): List<NetworkSession> = withConnection {
        rows("/ip/hotspot/active/print").map {
            NetworkSession(it[".id"].orEmpty(), it["user"].orEmpty(), it["address"].orEmpty(),
                it["mac-address"].orEmpty(), it["uptime"].orEmpty(), it["bytes-in"].orEmpty(),
                it["bytes-out"].orEmpty(), it["server"].orEmpty())
        }
    }

    fun addHotspotUser(name: String, password: String, profile: String, comment: String = "") = withConnection {
        val args = mutableListOf("=name=$name", "=password=$password", "=profile=$profile")
        if (comment.isNotBlank()) args += "=comment=$comment"
        add("/ip/hotspot/user/add", *args.toTypedArray())
    }

    fun addHotspotUsersBulk(users: List<Triple<String, String, String>>): BulkResult = withConnection {
        var completed = 0
        try {
            users.forEach { (name, password, profile) ->
                add("/ip/hotspot/user/add", "=name=$name", "=password=$password", "=profile=$profile")
                completed++
            }
            BulkResult(completed)
        } catch (e: Exception) {
            BulkResult(completed, e.message ?: "فشل إنشاء أحد المستخدمين")
        }
    }

    fun removeHotspotUser(id: String) = withConnection { remove("/ip/hotspot/user/remove", id) }
    fun setHotspotUserDisabled(id: String, disabled: Boolean) = withConnection {
        command("/ip/hotspot/user/set", "=.id=$id", "=disabled=${if (disabled) "yes" else "no"}")
    }
    fun disconnectHotspotSession(id: String) = withConnection { remove("/ip/hotspot/active/remove", id) }

    fun addHotspotProfile(profile: PackageProfile) = withConnection {
        val args = mutableListOf("=name=${profile.name}")
        if (profile.rateLimit.isNotBlank()) args += "=rate-limit=${profile.rateLimit}"
        if (profile.sharedUsers.isNotBlank()) args += "=shared-users=${profile.sharedUsers}"
        add("/ip/hotspot/user/profile/add", *args.toTypedArray())
    }

    fun removeHotspotProfile(profileName: String) = withConnection {
        val row = rows("/ip/hotspot/user/profile/print", "?name=$profileName").firstOrNull()
            ?: error("الباقة غير موجودة")
        remove("/ip/hotspot/user/profile/remove", row[".id"] ?: error("معرّف الباقة غير متاح"))
    }

    private fun userManagerBase(): String {
        umBase?.let { return it }
        val version = rosMajor ?: rows("/system/resource/print").firstOrNull()?.get("version")?.substringBefore('.')?.toIntOrNull().also { rosMajor = it }
        val base = if (version != null && version >= 7) "/user-manager" else "/tool/user-manager"
        umBase = base
        return base
    }

    fun userManagerUsers(): List<UmUser> = withConnection {
        val base = userManagerBase()
        val result = rows("$base/user/print")
        val assignedProfiles = if (base.startsWith("/tool/")) emptyMap() else {
            try {
                rows("$base/user-profile/print")
                    .filter { it["state"] == "running active" || it["state"].isNullOrBlank() }
                    .associate { it["user"].orEmpty() to it["profile"].orEmpty() }
            } catch (_: Exception) { emptyMap() }
        }
        result.map {
            val isV6 = base.startsWith("/tool/")
            val username = if (isV6) it["username"].orEmpty() else it["name"].orEmpty()
            UmUser(it[".id"].orEmpty(), username,
                it["actual-profile"] ?: it["profile"] ?: assignedProfiles[username].orEmpty(),
                it["disabled"] == "true" || it["disabled"] == "yes", it["customer"] ?: "admin")
        }
    }

    fun userManagerProfiles(): List<PackageProfile> = withConnection {
        val base = userManagerBase()
        rows("$base/profile/print").map {
            PackageProfile(it["name"].orEmpty(), validity = it["validity"].orEmpty(), price = it["price"] ?: "0")
        }
    }

    fun userManagerSessions(): List<NetworkSession> = withConnection {
        val base = userManagerBase()
        rows("$base/session/print").map {
            NetworkSession(it[".id"].orEmpty(), it["user"] ?: it["username"].orEmpty(),
                it["user-address"].orEmpty(), it["calling-station-id"].orEmpty(), it["uptime"].orEmpty(),
                it["download"].orEmpty(), it["upload"].orEmpty())
        }
    }

    /** Router-side payment history, when the installed User Manager version exposes it. */
    fun userManagerPayments(): List<UmPayment> = withConnection {
        val base = userManagerBase()
        try {
            rows("$base/payment/print").mapIndexed { index, row ->
                val user = row["user"].orEmpty()
                val started = row["trans-start"].orEmpty()
                val status = row["trans-status"].orEmpty()
                UmPayment(
                    id = row[".id"] ?: "$index-$user-$started",
                    user = user,
                    profile = row["profile"].orEmpty(),
                    price = row["price"].orEmpty(),
                    currency = row["currency"].orEmpty(),
                    method = row["method"].orEmpty(),
                    status = status,
                    transStart = started,
                    transEnd = row["trans-end"].orEmpty()
                )
            }
        } catch (_: Exception) {
            // Some legacy packages/builds do not expose the payment menu over API.
            emptyList()
        }
    }

    fun addUserManagerUser(name: String, password: String, profile: String, sharedUsers: Int = 1) = withConnection {
        val base = userManagerBase()
        if (base.startsWith("/tool/")) {
            add("$base/user/add", "=customer=admin", "=username=$name", "=password=$password", "=shared-users=$sharedUsers")
            if (profile.isNotBlank()) {
                add("$base/user/create-and-activate-profile", "=customer=admin", "=numbers=$name", "=profile=$profile")
            }
        } else {
            add("$base/user/add", "=name=$name", "=password=$password", "=shared-users=$sharedUsers")
            if (profile.isNotBlank()) add("$base/user-profile/add", "=user=$name", "=profile=$profile")
        }
    }

    fun addUserManagerUsersBulk(users: List<Triple<String, String, String>>): BulkResult = withConnection {
        val base = userManagerBase()
        var completed = 0
        try {
            users.forEach { (name, password, profile) ->
                if (base.startsWith("/tool/")) {
                    add("$base/user/add", "=customer=admin", "=username=$name", "=password=$password", "=shared-users=1")
                    if (profile.isNotBlank()) add("$base/user/create-and-activate-profile", "=customer=admin", "=numbers=$name", "=profile=$profile")
                } else {
                    add("$base/user/add", "=name=$name", "=password=$password", "=shared-users=1")
                    if (profile.isNotBlank()) add("$base/user-profile/add", "=user=$name", "=profile=$profile")
                }
                completed++
            }
            BulkResult(completed)
        } catch (e: Exception) {
            BulkResult(completed, e.message ?: "فشل إنشاء أحد المستخدمين")
        }
    }

    fun removeUserManagerUser(id: String) = withConnection {
        remove("${userManagerBase()}/user/remove", id)
    }

    fun setUserManagerUserDisabled(id: String, disabled: Boolean) = withConnection {
        command("${userManagerBase()}/user/set", "=.id=$id", "=disabled=${if (disabled) "yes" else "no"}")
    }

    fun addUserManagerProfile(profile: PackageProfile) = withConnection {
        val base = userManagerBase()
        val fallbackValidity = if (base.startsWith("/tool/")) "0s" else "unlimited"
        val args = mutableListOf("=name=${profile.name}", "=validity=${profile.validity.ifBlank { fallbackValidity }}")
        profile.price.toDoubleOrNull()?.let { args += "=price=$it" }
        if (base.startsWith("/tool/")) {
            // Legacy User Manager (RouterOS 6) uses owner and starts-at fields.
            args += "=owner=admin"
            args += "=starts-at=logon"
        } else {
            // User Manager 5 (RouterOS 7) uses starts-when.
            args += "=starts-when=first-auth"
        }
        add("$base/profile/add", *args.toTypedArray())
    }

    fun removeUserManagerProfile(name: String) = withConnection {
        val base = userManagerBase()
        val row = rows("$base/profile/print", "?name=$name").firstOrNull() ?: error("الباقة غير موجودة")
        remove("$base/profile/remove", row[".id"] ?: error("معرّف الباقة غير متاح"))
    }

    private fun close() {
        try { socket?.close() } catch (_: Exception) { }
        socket = null; input = null; output = null
    }
}
