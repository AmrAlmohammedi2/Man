package com.managerman.app

data class RouterProfile(
    val name: String,
    val host: String,
    val port: Int,
    val user: String,
    val pass: String
)

data class HotspotUser(
    val id: String,
    val name: String,
    val profile: String,
    val comment: String,
    val disabled: Boolean = false,
    val limitUptime: String = "",
    val limitBytesTotal: String = ""
)

data class UmUser(
    val id: String,
    val name: String,
    val profile: String,
    val disabled: Boolean = false,
    val customer: String = "admin"
)

data class PackageProfile(
    val name: String,
    val rateLimit: String = "",
    val sharedUsers: String = "1",
    val validity: String = "",
    val price: String = "0"
)

data class NetworkSession(
    val id: String,
    val username: String,
    val address: String,
    val mac: String,
    val uptime: String,
    val download: String,
    val upload: String,
    val server: String = ""
)

data class RouterInfo(
    val version: String = "",
    val board: String = "",
    val uptime: String = "",
    val cpuLoad: String = "",
    val freeMemory: String = "",
    val totalMemory: String = ""
)

data class CredentialCard(
    val id: String,
    val username: String,
    val password: String,
    val profile: String,
    val target: String,
    val price: Double,
    val createdAt: Long
)

data class SaleRecord(
    val id: String,
    val username: String,
    val profile: String,
    val amount: Double,
    val customer: String,
    val note: String,
    val createdAt: Long
)

data class CardDesign(
    val networkName: String = "مديرمان للإنترنت",
    val title: String = "بطاقة إنترنت",
    val footer: String = "شكراً لاستخدامكم شبكتنا",
    val template: String = "أزرق",
    val showPassword: Boolean = true,
    val showPrice: Boolean = true
)

data class BulkResult(val createdCount: Int, val error: String? = null)


data class UmPayment(
    val id: String,
    val user: String,
    val profile: String,
    val price: String,
    val currency: String,
    val method: String,
    val status: String,
    val transStart: String,
    val transEnd: String
)
