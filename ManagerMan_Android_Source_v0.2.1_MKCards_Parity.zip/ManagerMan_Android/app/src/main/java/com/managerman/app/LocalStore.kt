package com.managerman.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("managerman_local", Context.MODE_PRIVATE)

    fun saveRouter(router: RouterProfile) {
        val array = JSONArray(prefs.getString("routers", "[]"))
        val obj = JSONObject()
            .put("name", router.name)
            .put("host", router.host)
            .put("port", router.port)
            .put("user", router.user)
            .put("passEnc", DeviceCrypto.encrypt(router.pass))
        var replaced = false
        for (i in 0 until array.length()) {
            if (array.getJSONObject(i).optString("host") == router.host) {
                array.put(i, obj); replaced = true; break
            }
        }
        if (!replaced) array.put(obj)
        prefs.edit().putString("routers", array.toString()).apply()
    }

    fun routers(): List<RouterProfile> {
        val array = JSONArray(prefs.getString("routers", "[]"))
        val result = mutableListOf<RouterProfile>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val encryptedOrLegacy = obj.optString("passEnc", obj.optString("pass"))
            val password = try { DeviceCrypto.decrypt(encryptedOrLegacy) } catch (_: Exception) { "" }
            result += RouterProfile(
                obj.optString("name"), obj.optString("host"), obj.optInt("port", 8728),
                obj.optString("user"), password
            )
            // Migrate old plaintext router credentials to Android Keystore encryption.
            if (!obj.has("passEnc")) saveRouter(result.last())
        }
        return result
    }

    fun removeRouter(host: String) {
        val current = routers().filterNot { it.host == host }
        val arr = JSONArray()
        current.forEach { r -> arr.put(routerJson(r, includePlainPassword = false)) }
        prefs.edit().putString("routers", arr.toString()).apply()
    }

    private fun readSecureArray(key: String): JSONArray {
        val stored = prefs.getString(key, "[]") ?: "[]"
        val clear = try { DeviceCrypto.decrypt(stored) } catch (_: Exception) { "[]" }
        return JSONArray(clear)
    }

    private fun writeSecureArray(key: String, array: JSONArray) {
        prefs.edit().putString(key, DeviceCrypto.encrypt(array.toString())).apply()
    }

    fun cards(): List<CredentialCard> {
        val arr = readSecureArray("cards")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            CredentialCard(o.optString("id"), o.optString("username"), o.optString("password"),
                o.optString("profile"), o.optString("target"), o.optDouble("price", 0.0), o.optLong("createdAt"))
        }
    }

    fun saveCards(cards: List<CredentialCard>) {
        val arr = JSONArray()
        cards.forEach { c -> arr.put(JSONObject().put("id", c.id).put("username", c.username)
            .put("password", c.password).put("profile", c.profile).put("target", c.target)
            .put("price", c.price).put("createdAt", c.createdAt)) }
        writeSecureArray("cards", arr)
    }

    fun sales(): List<SaleRecord> {
        val arr = readSecureArray("sales")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SaleRecord(o.optString("id"), o.optString("username"), o.optString("profile"),
                o.optDouble("amount", 0.0), o.optString("customer"), o.optString("note"), o.optLong("createdAt"))
        }.sortedByDescending { it.createdAt }
    }

    fun saveSales(sales: List<SaleRecord>) {
        val arr = JSONArray()
        sales.forEach { s -> arr.put(JSONObject().put("id", s.id).put("username", s.username)
            .put("profile", s.profile).put("amount", s.amount).put("customer", s.customer)
            .put("note", s.note).put("createdAt", s.createdAt)) }
        writeSecureArray("sales", arr)
    }

    fun design(): CardDesign {
        val o = JSONObject(prefs.getString("card_design", "{}"))
        return CardDesign(o.optString("networkName", "مديرمان للإنترنت"), o.optString("title", "بطاقة إنترنت"),
            o.optString("footer", "شكراً لاستخدامكم شبكتنا"), o.optString("template", "أزرق"),
            o.optBoolean("showPassword", true), o.optBoolean("showPrice", true))
    }

    fun saveDesign(d: CardDesign) {
        val o = JSONObject().put("networkName", d.networkName).put("title", d.title)
            .put("footer", d.footer).put("template", d.template)
            .put("showPassword", d.showPassword).put("showPrice", d.showPrice)
        prefs.edit().putString("card_design", o.toString()).apply()
    }

    fun backupJson(): String {
        val routersArray = JSONArray()
        routers().forEach { routersArray.put(routerJson(it, includePlainPassword = true)) }
        return JSONObject()
            .put("format", "ManagerMan-backup-v1")
            .put("createdAt", System.currentTimeMillis())
            .put("routers", routersArray)
            .put("cards", readSecureArray("cards"))
            .put("sales", readSecureArray("sales"))
            .put("cardDesign", JSONObject(prefs.getString("card_design", "{}")))
            .toString()
    }

    fun restoreJson(json: String) {
        val root = JSONObject(json)
        require(root.optString("format") == "ManagerMan-backup-v1") { "صيغة النسخة الاحتياطية غير مدعومة" }
        val routersIn = root.optJSONArray("routers") ?: JSONArray()
        val encryptedRouters = JSONArray()
        for (i in 0 until routersIn.length()) {
            val r = routersIn.getJSONObject(i)
            val profile = RouterProfile(r.optString("name"), r.optString("host"), r.optInt("port", 8728),
                r.optString("user"), r.optString("password"))
            encryptedRouters.put(routerJson(profile, includePlainPassword = false))
        }
        prefs.edit()
            .putString("routers", encryptedRouters.toString())
            .putString("cards", DeviceCrypto.encrypt((root.optJSONArray("cards") ?: JSONArray()).toString()))
            .putString("sales", DeviceCrypto.encrypt((root.optJSONArray("sales") ?: JSONArray()).toString()))
            .putString("card_design", (root.optJSONObject("cardDesign") ?: JSONObject()).toString())
            .apply()
    }

    private fun routerJson(r: RouterProfile, includePlainPassword: Boolean): JSONObject {
        val o = JSONObject().put("name", r.name).put("host", r.host).put("port", r.port).put("user", r.user)
        if (includePlainPassword) o.put("password", r.pass) else o.put("passEnc", DeviceCrypto.encrypt(r.pass))
        return o
    }

    companion object { fun newId(): String = UUID.randomUUID().toString() }
}
