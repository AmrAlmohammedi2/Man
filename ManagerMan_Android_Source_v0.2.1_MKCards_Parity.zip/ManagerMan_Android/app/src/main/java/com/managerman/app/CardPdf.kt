package com.managerman.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri

object CardPdf {
    fun write(context: Context, uri: Uri, cards: List<CredentialCard>, design: CardDesign) {
        require(cards.isNotEmpty()) { "لا توجد كروت لتصديرها" }
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val columns = 2
        val rows = 4
        val margin = 26f
        val gap = 12f
        val cardWidth = (pageWidth - 2 * margin - gap) / columns
        val cardHeight = (pageHeight - 2 * margin - gap * (rows - 1)) / rows

        val palette = when (design.template) {
            "أخضر" -> intArrayOf(Color.rgb(14, 91, 74), Color.rgb(222, 246, 235), Color.rgb(21, 110, 89))
            "داكن" -> intArrayOf(Color.rgb(27, 35, 48), Color.rgb(232, 237, 244), Color.rgb(42, 56, 76))
            "بنفسجي" -> intArrayOf(Color.rgb(76, 54, 120), Color.rgb(242, 235, 252), Color.rgb(111, 82, 169))
            else -> intArrayOf(Color.rgb(20, 67, 115), Color.rgb(230, 241, 252), Color.rgb(31, 111, 174))
        }

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 13f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val subTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 9f; alpha = 220; textAlign = Paint.Align.RIGHT
        }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = palette[0]; textSize = 9f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(28, 42, 57); textSize = 11f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 8f; textAlign = Paint.Align.RIGHT }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = palette[2]; strokeWidth = 1.2f; style = Paint.Style.STROKE }

        var pageNumber = 1
        cards.chunked(columns * rows).forEach { pageCards ->
            val page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber++).create())
            val canvas: Canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            pageCards.forEachIndexed { index, card ->
                val col = index % columns
                val row = index / columns
                val left = margin + col * (cardWidth + gap)
                val top = margin + row * (cardHeight + gap)
                val right = left + cardWidth
                val bottom = top + cardHeight
                val rect = RectF(left, top, right, bottom)

                val background = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = palette[1]; style = Paint.Style.FILL }
                canvas.drawRoundRect(rect, 10f, 10f, background)
                val header = RectF(left, top, right, top + 43f)
                val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = palette[0]; style = Paint.Style.FILL }
                canvas.drawRoundRect(header, 10f, 10f, headerPaint)
                canvas.drawRect(left, top + 28f, right, top + 43f, headerPaint)
                canvas.drawText(design.networkName.take(32), right - 12f, top + 17f, titlePaint)
                canvas.drawText(design.title, right - 12f, top + 32f, subTitlePaint)

                val rightX = right - 12f
                val leftX = left + 12f
                var y = top + 65f
                canvas.drawText("الباقة", rightX, y, labelPaint)
                canvas.drawText(card.profile, leftX + 70f, y, valuePaint)
                y += 25f
                canvas.drawText("اسم المستخدم", rightX, y, labelPaint)
                canvas.drawText(card.username, leftX + 150f, y, valuePaint)
                if (design.showPassword) {
                    y += 25f
                    canvas.drawText("كلمة المرور", rightX, y, labelPaint)
                    canvas.drawText(card.password, leftX + 150f, y, valuePaint)
                }
                if (design.showPrice) {
                    y += 25f
                    canvas.drawText("السعر", rightX, y, labelPaint)
                    canvas.drawText(if (card.price > 0) "${card.price}" else "—", leftX + 150f, y, valuePaint)
                }
                canvas.drawLine(left + 10f, bottom - 25f, right - 10f, bottom - 25f, linePaint)
                canvas.drawText(design.footer, rightX, bottom - 10f, smallPaint)
            }
            document.finishPage(page)
        }
        try {
            context.contentResolver.openOutputStream(uri)?.use { output -> document.writeTo(output) }
                ?: error("تعذر فتح ملف PDF للكتابة")
        } finally {
            document.close()
        }
    }
}
