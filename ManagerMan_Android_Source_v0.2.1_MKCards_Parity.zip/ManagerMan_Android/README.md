# مديرمان – ManagerMan

Android app for managing MikroTik Hotspot and User Manager through a local Wi-Fi/LAN connection. Core router management does not require an internet connection or cloud account.

## Version 0.2.1 — expanded MKCards feature coverage

This release implements the major feature groups publicly described for MKCards, using an independent codebase and ManagerMan branding:

- **Router connections:** save multiple MikroTik routers, switch between them, and keep router credentials encrypted at rest using Android Keystore.
- **Router status:** read RouterOS version, board, uptime, CPU load, and memory values.
- **Hotspot administration:** list/search users, add users, enable/disable accounts, delete accounts, and list/add/delete Hotspot user profiles.
- **User Manager administration:** list/search users, add users, enable/disable/delete users, and list/add/delete profiles for RouterOS 6 legacy User Manager and RouterOS 7 User Manager.
- **Sessions:** display active Hotspot sessions and disconnect them; read User Manager session history where RADIUS accounting data is available.
- **User Manager reports:** summarize session counts and traffic; display payment records exposed by the User Manager payment menu. Payment totals include only transactions whose status is `approved`.
- **Voucher generation:** create up to 500 username/password vouchers per batch for Hotspot or User Manager, save the generated card credentials locally, and associate a profile and price.
- **Card management and print design:** retain voucher records, configure network name/title/footer, choose from four built-in templates, and select whether passwords and prices appear on the ticket.
- **PDF output:** export eight designed vouchers per A4 page to a PDF that can be saved, shared, or printed using Android's document picker.
- **Sales and payment records:** register local card sales, customer details, prices, notes, and see today's and overall totals. This is local bookkeeping, not an online payment gateway.
- **Encrypted backup and restore:** create portable backups protected with PBKDF2-HMAC-SHA256 and AES-256-GCM; restore router profiles, card credentials, card design, and local sales on another phone with the backup password.

The dashboard includes direct shortcuts to the main modules. The app remains local-first; cloud synchronization is intentionally not activated in this release.

## Build

Requirements: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, Gradle 8.11.1.

```bash
gradle :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

GitHub Actions workflow: `.github/workflows/android.yml`.

## Router configuration and security

1. Enable MikroTik API: `/ip service set api disabled=no`.
2. Allow TCP/8728 only from the Android phone's LAN address in the router firewall.
3. Prefer a dedicated API account with only the policies needed for the selected operations.
4. Keep the app and router on a trusted local network. Do not expose TCP/8728 to the public Internet. The normal API service on TCP/8728 does not provide transport encryption; API-SSL on TCP/8729 requires a correctly configured and trusted certificate and is not yet implemented as a transport option in this app.

## RouterOS compatibility notes

- RouterOS 7 User Manager commands use `/user-manager/...`.
- RouterOS 6 legacy User Manager commands use `/tool/user-manager/...`; user creation and profile activation use the legacy `customer=admin` and `numbers=<username>` command arguments.
- RouterOS 6 profile definitions use legacy fields including `owner=admin` and `starts-at=logon`; RouterOS 7 uses `starts-when=first-auth`.
- The legacy RouterOS 6 implementation currently assumes the standard User Manager customer/owner name `admin`. If the router uses a different customer, this must be configurable in a later patch.
- Payment history is optional: it appears only when the installed User Manager package and permissions expose the payment menu over API.
- User Manager session reports depend on RADIUS accounting being configured and receiving accounting records. An empty report does not necessarily mean the router has no active users.

## Scope and validation

The features above are implemented in the source, but this archive has **not been built or tested against your physical router in this environment**. RouterOS API commands differ between legacy and current User Manager implementations, and availability depends on the installed package, RouterOS version, customer/owner configuration, and API permissions. Test profile creation, bulk user generation, disabling/deleting a user, and report access with a small test batch before using them on production credentials.

Not included yet: cloud sync/account login, online payment gateway integration, arbitrary image-based card backgrounds, a full drag-and-drop template editor, API-SSL transport, and editing existing voucher usernames/passwords. These are beyond the currently published feature parity scope and should be added in separate tested iterations.
